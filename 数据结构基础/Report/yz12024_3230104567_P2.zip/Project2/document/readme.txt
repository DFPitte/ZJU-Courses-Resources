Please enter an expression that contains variables (such as a, b, c) and operators such as (+, -, *,,, ^)
Please note that the output may contain extra zeros and some strange extra operators, but it does not affect the final result. It only makes the final result less aesthetically pleasing. Please automatically ignore it when reading the results. I apologize for any inconvenience this may cause.

Some examples are as follows:
a+b+c
a^b*c
a*b*c
(b+c)*a
etc.