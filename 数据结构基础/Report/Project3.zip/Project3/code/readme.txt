Please use c++ compiler to compile the program named "Transportation Hub.cpp".
input1.txt , input2.txt , input3.txt are some example inputs,please change input*.txt in the program "freopen" function to test the other test cases.
The right output is given in the report,please check that.I sincerely hope you can open and run the program successfully.
