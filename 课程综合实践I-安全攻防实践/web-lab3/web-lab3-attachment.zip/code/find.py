import hashlib

payload = "QWERTYUIOPASDFGHJKLZXCVBNM"
count = 0

def calcMd5(s):
    global count
    count += 1
    
    MD5 = hashlib.md5(s.encode('utf-8')).hexdigest()
    if MD5[0:2] == "0e" and MD5[2:32].isdigit():
        print(f"Found match: {s}, {MD5}")

def getStr(payload, s, slen):
    if len(s) == slen:
        calcMd5(s)
        return s    
    for j in range(len(payload)):
        sl = s + payload[j]
        getStr(payload, sl, slen)

if __name__ == '__main__':
    
    getStr(payload, '', 7)